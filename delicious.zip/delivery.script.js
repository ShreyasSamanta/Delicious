var page = document.querySelector("body");
function myFunction() {
    page.classList.toggle("light-mode");
  }
  
  console.log(page);